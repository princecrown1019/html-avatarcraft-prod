$('.resopen').click(
function(){
				$(".resmenu").css("left","0");
				$(".resmenu").css("opacity","1");
        $(".resmenu").css("visibility","visible");
				$(".closemenu").css("opacity","0.5");
        $(".closemenu").css("visibility","visible");
});
	  	
		
$('.closemenu').click(
function(){
				$(".resmenu").css("left","-500px");
				$(".resmenu").css("opacity","0");
        $(".resmenu").css("visibility","hidden");
				$(".closemenu").css("opacity","0");
        $(".closemenu").css("visibility","hidden");
});
	
$('.close2').click(
  function(){
          $(".resmenu").css("left","-500px");
          $(".resmenu").css("opacity","0");
          $(".resmenu").css("visibility","hidden");
          $(".closemenu").css("opacity","0");
          $(".closemenu").css("visibility","hidden");
});


$('.slider').slick({
	arrows:true,
	centerMode: true,
	centerPadding: '60px',
    prevArrow:".prev1",
    nextArrow:".next1",
});

var au = $('.au');
au.on('click', function(e) {e.preventDefault();$('html, body').animate({scrollTop:0}, '300');});